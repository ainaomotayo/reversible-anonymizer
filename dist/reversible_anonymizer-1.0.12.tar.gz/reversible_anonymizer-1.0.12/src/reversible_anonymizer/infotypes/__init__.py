"""Infotypes package for managing DLP info types."""
from .catalog import InfoTypeCatalog

__all__ = ["InfoTypeCatalog"]